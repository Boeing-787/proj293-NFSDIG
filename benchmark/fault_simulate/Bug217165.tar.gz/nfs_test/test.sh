#!/bin/bash

./mid.sh && echo running
