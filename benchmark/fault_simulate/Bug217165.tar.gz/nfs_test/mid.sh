#!/bin/bash

./lost.sh 2> time.txt & disown $!
