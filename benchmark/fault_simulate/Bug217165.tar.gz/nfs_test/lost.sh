#!/bin/bash

sleep 1
time ls -la /mnt/nas >/dev/null
